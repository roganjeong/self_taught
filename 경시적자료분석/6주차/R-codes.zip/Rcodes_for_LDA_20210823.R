setwd('D:/저서-번역/경시적자료분석/Codes')

#-----------------------------------------------#
#          Blood lead level in TLC trial         #
#-----------------------------------------------#

library(psych)
tlc <- read.table("tlc.txt", col.names=c("ID","Group","week.0","week.1","week.4","wkk.6"))

# long style data
tlcl <- reshape(tlc,direction="long", 
                 varying=list(c("week.0","week.1","week.4","wkk.6")),
                 v.names="lead",
                 timevar="week",
                 times=c(0,1,4,6),
                 idvar="ID")

plot(lead ~ week, data=tlcl, pch=".",
     xlab="Week",
     ylab="Blood lead level")


png("ch1-tlc.png")
s <- sample(unique(tlcl$ID),size=4)
plot(lead ~ week, data=tlcl, col="gray50",
     xlab="Week",
     ylab="Blood lead level")
for(i in 1:4){
 lines(tlcl$week[tlcl$ID==s[i]],
       tlcl$lead[tlcl$ID==s[i]],lwd=1.5)
}
dev.off()

# Spaghetti plot
library(lattice)
tlcl.grp1 <- tlcl[tlcl$Group=="P",]
tlcl.grp2 <- tlcl[tlcl$Group=="A",]
png("ch3-tlc-P.png")
xyplot(lead ~ week, data=tlcl.grp1,xlim=c(-1,7), ylim=c(0,50), type="l", group=ID,
       xlab="Week",
       col.line="gray20",
       ylab="Blood lead level", main='Placebo group')
dev.off()
png("ch3-tlc-A.png")
xyplot(lead ~ week, data=tlcl.grp2,xlim=c(-1,7), ylim=c(0,50), type="l", group=ID,
       xlab="Week",
       col.line="gray20",
       ylab="Blood lead level", main='Succimer group')
dev.off()

library(psych)
png("mult-correlation_tlc.png")
pairs.panels(tlc[,c("week.0","week.1","week.4","wkk.6")])
dev.off()

# Simple linear regression
# make referecne category for "P"
tlcl$Group.f <- relevel(factor(tlcl$Group),ref="P")
tlc.lm <- lm(lead ~ factor(week)*Group.f, data=tlcl)
summary(tlc.lm)
anova(tlc.lm)

png('reg_diagnosis.png')
par(mfrow=c(2,2))
plot(tlc.lm)
dev.off()

# General linear model using ML & REML
library(nlme)

# sorting data by ID and week
o <- order(tlcl$Group,tlcl$ID,tlcl$week)
tlcl <- tlcl[o,]
# ML
tlc.ml <- gls(lead~factor(week)*Group.f, data=tlcl, method="ML", 
                 correlation=corCompSymm(form=~1|ID))
summary(tlc.ml)
# REML
tlc.reml <- gls(lead~factor(week)*Group.f, data=tlcl, method="REML", 
                 correlation=corCompSymm(form=~1|ID))
summary(tlc.reml)

# model diagnosis
plot(tlc.ml, resid(.)~ID, id=0.01)
png('gls_diagnosis1.png')
plot(tlc.ml,resid(.)~week | Group, abline=0, id=~ID==40)
dev.off()
png('gls_diagnosis2.png')
plot(tlc.ml,resid(.,type="p")~fitted(.) | Group, id=~ID==40)
dev.off()

png('gls_qqnorm.png')
qqnorm(tlc.ml, ~resid(.))
dev.off()

# General linear model using GEE
library(gee)
# independence working correlation
tlcl.gee.indep <- gee(lead ~ factor(week)*Group.f,,id=ID,corstr="independence",data=tlcl)
summary(tlcl.gee.indep)

# exchangeable working correlation
tlcl.gee.exchange <- gee(lead ~ factor(week)*Group.f,,id=ID,corstr="exchangeable",data=tlcl)
summary(tlcl.gee.exchange)

# unstructured working correlation
tlcl.gee.unstruct <- gee(lead ~ factor(week)*Group.f,,id=ID,corstr="unstructured",data=tlcl)
summary(tlcl.gee.unstruct)


#-----------------------------------------------#
#                CD4+ Data                        #
#-----------------------------------------------#

CD4 <- read.table("cd4.dat",header=TRUE)

# Scatter plot
#png("ch1-pic1.png")
plot(CD4 ~ Time, data=CD4, pch=".",
     xlab="Years since seroconversion",
     ylab="CD4+ cell number")
#dev.off()


# Choose 4 random individuals
#png("ch1-pic3.png")
s <- sample(unique(CD4$ID),size=4)
plot(CD4 ~ Time, data=CD4, col="gray50",
     xlab="Years since seroconversion",
     ylab="CD4+ cell number")
for(i in 1:4){
 lines(CD4$Time[CD4$ID==s[i]],
       CD4$CD4[CD4$ID==s[i]],lwd=1.5)
}
#dev.off()

# Spaghetti plot
library(lattice)
#png("ch2-CD4-spaghetti.png")
xyplot(CD4 ~ Time, data=CD4, type="l", group=ID,
       xlab="Years since seroconversion",
       col.line="gray20",
       ylab="CD4+ cell numbers")
#dev.off()

#png("ch3-CD4-age-spaghetti.png")
xyplot(CD4 ~ Time | equal.count(Age,6), data=CD4,
       type="l", group=ID,
       xlab="Years since seroconversion",
       col.line="gray20",
       ylab="CD4+ cell number",
       strip=strip.custom(var.name="Age"))
#dev.off()

# Smoothing Spline
#png("ch3-CD4-smoohting.png")
plot(CD4 ~ Time, data=CD4, col="gray50", pch=".",
     xlab="Years since seroconversion",
     ylab="CD+ cell number")
with(CD4, {
   lines(ksmooth(Time, CD4, kernel="normal"),lty=1,col=1,lwd=2)
   lines(loess.smooth(Time,CD4,family="gaussian"),lty=2,col=2,lwd=2)
   lines(smooth.spline(Time,CD4),lty=3,col=3,lwd=2)
   lines(supsmu(Time,CD4),lty=4,col=4,lwd=2)
})
legend(1.8,3000,legend=c("Gaussian Kernal", "Gaussian Loess",
        "Gubic Smooth Spline", "Super Smoother"),
        lty=1:4,col=1:4)
#dev.off()

# Exploring Correlation structure
#png("ch3-CD4-multicorrelation.png")
CD4.lm <- lm(CD4 ~ Time, data=CD4)
CD4$lmres <- resid(CD4.lm)
CD4$roundyr <- round(CD4$Time)
CD4w <- reshape(CD4[,c("ID","lmres","roundyr")],
                 direction="wide",v.names="lmres",
                 timevar="roundyr",idvar="ID")

library(psych)
pairs.panels(CD4w[,c(5,2,3,6:8)])
#dev.off()


# Variogram
#png("ch3-variogram.png")
lda.vg <- function(id,res,time,plot=TRUE,...)
{
  vv <- tapply(res,id,function(x) outer(x,x,function(x,y)(x-y)^2/2))
  v <- unlist(lapply(vv,function(x) x[lower.tri(x)]))
  uu <- tapply(time,id,function(x) outer(x,x,function(x,y)(x-y)))
  u <- unlist (lapply(uu , function (x) x[lower.tri(x)]))
  if (plot) {
    vg.loess <- loess.smooth (u,v,family="gaussian")
    plot(v~u,pch=".",col="gray50", ...)
    lines (vg.loess,lty=1)
    abline(h=var(res),lty=2)
  }
  invisible ( data.frame (v = v, u = u))
}
lda.vg(CD4$ID,CD4$lmres,CD4$Time,ylim=c(0,170000),ylab="",xlab="")
#dev.off()


# Empirical autocorrelation function
CD4.lm <- lm(CD4 ~ Time, data=CD4)
CD4$lmres <- resid(CD4.lm)



# chap. 5 linear mixed models

library(nlme)
CD4 <- read.table("cd4.dat",header=TRUE)
CD4$Time2 <- ifelse(CD4$Time <0, 0, CD4$Time) # 혈청전환 전을 0으로 변환함
CD4g <- groupedData(CD4 ~ Time | ID, data=CD4, FUN=median, 
                                 labels=list(x="Time since seroconversion",
                                 outer= ~Age,
                                 labels=list(y="CD4+ Cell Number")),
                                 units=list(x="(yr)",y=""))

gsummary(CD4g, FUN=function(x) max(x,na.rm=TRUE))[1:5,]
gsummary(CD4g, FUN=function(x) min(x,na.rm=TRUE))[1:5,]

CD4.lm <- lm(I(sqrt(CD4)) ~ Cesd+Drugs+Sex+Packs+Time2+I(Time2^2), data=CD4)
summary(CD4.lm)

library(MASS)
png("CD4.lm.png")
par(mfrow=c(2,1))
plot(fitted(CD4.lm),stdres(CD4.lm), xlab="Fitted value",ylab="Standardized residual", main="Standardized res. vs Fitted values")
qqnorm(stdres(CD4.lm))
dev.off()

temp <- subset(CD4, Time <4)
cd4.lmt <- lm(I(sqrt(CD4)) ~ Time2+I(Time2^2), data=temp)
temp$fitted <- fitted(cd4.lmt)^2
temp <- temp[order(temp$Time),]
plot(CD4 ~ Time, data=temp, col="gray50", pch=".",
       xlab="Years since seroconversion", ylab="CD4+ cell number")
lines(temp$fitted ~ temp$Time)

# Linear mixed model with error ~iid N(0,sigma^2)
CD4.lme <- lme(I(sqrt(CD4))~ Cesd+Drugs+Sex+Packs+Time2+I(Time2^2),
                          data=CD4g, random=~1|ID)
summary(CD4.lme)

# autocorrelation function
ACF(CD4.lme) 
plot(ACF(CD4.lme), alpha=0.01 )
# variogram
Variogram(CD4.lme)

r   <- tapply(resid(CD4.lme),CD4$ID, function(x) x)
dt <- tapply(CD4$Time, CD4$ID, 
  function(x){
    tmp <- outer(x, x, "-")
    abs(tmp[lower.tri(tmp)])
  }
)

non.singles <- which(sapply(r,length) != 1)
r <- r[non.singles]
dt <- dt[non.singles]
CD4.v <- mapply(function(x,y) Variogram(x,y), r, dt, SIMPLIFY=FALSE)

CD4.v <- do.call("rbind", CD4.v)
temp <- loess.smooth(x=CD4.v$dist, y=CD4.v$variog, family="gaussian")

png('CD4-variogram.png')
plot(variog ~ dist, data=CD4.v, ylim=c(0,100),col="gray70", 
                               xlab="time difference", ylab="variogram")
lines(temp, lty=1, lwd=2)
#abline(h=var(unlist(r)), lwd=2, lty=2)
dev.off()

# Linear mixed model with error having exponential correlation
CD4.lme2 <- lme(I(sqrt(CD4))~ Cesd+Drugs+Sex+Packs+Time2+I(Time2^2),
                      data=CD4g, random=~1|ID, 
                      correlation=corExp(form=~Time,value=0.1))
summary(CD4.lme2)

# LRT test for two models
anova(CD4.lme2, CD4.lme)
intervals(CD4.lme2)


#---------------------------------------------------#
#        Indonesian Children's Health Study       #
#---------------------------------------------------#

ICHS <- read.table("ICHS.dat", header = TRUE)
table(ICHS$VITA,ICHS$RESPONSE)

ICHSw <- reshape(ICHS[,c("ID","RESPONSE","TIME","GENDER","VITA","AGE")],
                 direction="wide",v.names="RESPONSE",
                 timevar="TIME",idvar="ID")

# tables for vita vs response at each week
table(ICHSw$VITA, ICHSw$RESPONSE.0)
table(ICHSw$VITA, ICHSw$RESPONSE.3)
table(ICHSw$VITA, ICHSw$RESPONSE.6)
table(ICHSw$VITA, ICHSw$RESPONSE.9)
table(ICHSw$VITA, ICHSw$RESPONSE.12)
table(ICHSw$VITA, ICHSw$RESPONSE.15)

# odds ratio using tables for past response vs current response
table(ICHSw$RESPONSE.0,ICHSw$RESPONSE.3)
table(ICHSw$RESPONSE.0,ICHSw$RESPONSE.6)
table(ICHSw$RESPONSE.0,ICHSw$RESPONSE.9)
table(ICHSw$RESPONSE.0,ICHSw$RESPONSE.12)
table(ICHSw$RESPONSE.0,ICHSw$RESPONSE.15)

table(ICHSw$RESPONSE.3,ICHSw$RESPONSE.6)
table(ICHSw$RESPONSE.3,ICHSw$RESPONSE.9)
table(ICHSw$RESPONSE.3,ICHSw$RESPONSE.12)
table(ICHSw$RESPONSE.3,ICHSw$RESPONSE.15)


table(ICHSw$RESPONSE.6,ICHSw$RESPONSE.9)
table(ICHSw$RESPONSE.6,ICHSw$RESPONSE.12)
table(ICHSw$RESPONSE.6,ICHSw$RESPONSE.15)

table(ICHSw$RESPONSE.9,ICHSw$RESPONSE.12)
table(ICHSw$RESPONSE.9,ICHSw$RESPONSE.15)

table(ICHSw$RESPONSE.12,ICHSw$RESPONSE.15)


# GLM
ig.glm <-glm(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
           data=ICHS,family="binomial")
summary(ig.glm)

# GEE model using library gee
library (gee)

# exchangeable working correlation
ig.exc <- gee(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
           scale.fix=TRUE,cor="exchangeable",
           id=ID,data=ICHS,family="binomial")
summary(ig.exc)

# AR working correlation
ig.ar <- gee(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
           scale.fix=TRUE,cor="AR-M",
           id=ID,data=ICHS,family="binomial")
summary(ig.ar)

# Unstructured working correlation
ig.un <- gee(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
           scale.fix=TRUE,cor="unstructured",
           id=ID,data=ICHS,family="binomial")
summary(ig.un)


# GEE model using library geepack
# Model selection criterion: QIC

library (geepack)
ig2.exc <- geeglm(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
             id=ID,corstr="exchangeable",data=ICHS,family="binomial")
QIC(ig2.exc)

ig2.ar <- geeglm(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
             id=ID,corstr="ar1",data=ICHS,family="binomial")
QIC(ig2.ar)

ig2.un <- geeglm(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
             id=ID,corstr="unstructured",data=ICHS,family="binomial")
QIC(ig2.un)


#---------------------------------------------------#
#        NIMSCS Data from R package mixor     #
#---------------------------------------------------#

library(mixor)
data("schizophrenia") 
length(unique(schizophrenia$id))  # number of subjects
table(schizophrenia[schizophrenia$Week==0,]$TxDrug)

# exclude Week=2, 4, 5
schiz.id <- (schizophrenia$Week!=2)&(schizophrenia$Week!=4)&(schizophrenia$Week!=5)
schiz.ord <- schizophrenia[schiz.id,] 
length(unique(schiz.ord$id))  # number of subjects

table(schiz.ord$imps79o,schiz.ord$Week)


#---------------------------------------------------#
# McKinney Homeless Research Project (MHRP) #
#---------------------------------------------------#

MHRP <-read.table('sdhouse.dat',header=T)
T0 <- MHRP$time1==0 & MHRP$time2==0 & MHRP$time3==0 
T1 <- MHRP$time1==1
T2 <- MHRP$time2==1
T3 <- MHRP$time3==1

table(MHRP[T0,]$Sec8,MHRP[T0,]$housing)
table(MHRP[T1,]$Sec8,MHRP[T1,]$housing)
table(MHRP[T2,]$Sec8,MHRP[T2,]$housing)
table(MHRP[T3,]$Sec8,MHRP[T3,]$housing)


#---------------------------------------------------#
#                   Epileptic seizures                   #
#---------------------------------------------------#

library(gee)
library(geepack)

seize<-read.table("seize.data",col.names=c("id","seizure","week","progabide","baseline8","age"))

# Seizure data analysis 
seize.base <- data.frame(id=seize$id,seizure=seize$baseline8,week=seize$week,progabide=seize$prog,age=seize$age)
seize.base <- seize.base[seize.base$week==1,]
seize.base$week<-0

seize.full<-rbind(seize[,c(1:4,6)],seize.base[,])
seize.full <- seize.full[order(seize.full$id,seize.full$week),]
seize.full$time <- ifelse(seize.full$week==0,8,2)
seize.full$post <- seize.full$week!= 0
seize.full[1:10,]

# grand mean trend
week0 <- seize.full$week==0
week1 <- seize.full$week==1
week2 <- seize.full$week==2
week3 <- seize.full$week==3
week4 <- seize.full$week==4

mean(seize.full[week0,2])
mean(seize.full[week1,2])
mean(seize.full[week2,2])
mean(seize.full[week3,2])
mean(seize.full[week4,2])


# generalized linear model using Poisson distribution
seize.glm <- glm(seizure~age+baseline8+progabide,
                 data=seize,subset=week==4,family=poisson)
summary(seize.glm)

# quasi-likelihood approach
seize.glm2 <- glm(seizure~age+baseline8+progabide,
                 data=seize,subset=week==4,
                 family=quasi(link=log,variance="mu"))
summary(seize.glm2)


# GEE models 
# exchangeable correlation structure
sg.exc<-geeglm(seizure~progabide+post+post:progabide+offset(log(time)), 
         data=seize.full,id=id,family="poisson",cor="exchangeable")
summary(sg.exc)
QIC(sg.exc)

#  AR correlation structure
sg.ar1<-geeglm(seizure~progabide+post+post:progabide+offset(log(time)), 
         data=seize.full,id=id,family="poisson",cor="ar1")
summary(sg.ar1)
QIC(sg.ar1)

# GEE model with exchangeable correlation and 
# dispersion parameter depending treatments
# Yan and Fine (2004) model
sg2 <- geese(seizure ~ progabide+post+post:progabide+offset(log(time)),
             sformula= ~ progabide,data=seize.full,id=id,family="poisson",
             corstr="exchangeable")
summary(sg2)





#---------------------------------------------------#
#                   2*3  Crossover trial                 #
#---------------------------------------------------#

xover3 <- read.table("xover3.data",col.names=c("id","class","relief",
 "intercept","tx2","tx3","p2","p3","ptx1","ptx2","ptx3"))
xover3$period <- ifelse(xover3$p2==1,2, ifelse (xover3$p3==1,3,1))
xover3$treatment <- ifelse(xover3$tx2==1,2, ifelse(xover3$tx3==1,3,1))  
with(xover3,ftable(period,relief,treatment))

xover3$ptx <- ifelse(xover3$ptx1==1,1,
                   ifelse(xover3$ptx2==1,2,3))
xover3$ptx[xover3$period==1]<-0
with(xover3,ftable(ptx,relief,treatment))

library(gee)

# gee with default working correlation matrix (independence)
xover.gee <- gee(relief~p2+p3+tx2+tx3+ptx2+ptx3,
                 data=xover3,scale.fix=TRUE,id = id,family = binomial)
summary(xover.gee)

# gee with unstructred working correlation matrix
xover.gee.unstr <- gee(relief~p2+p3+tx2+tx3+ptx2+ptx3,
                 data=xover3,scale.fix=TRUE,id = id,family = binomial, corstr="unstructured")
summary(xover.gee.unstr)


# Code for Conditional Logisitic Regression
library(survival)
xover3.cl <- clogit(relief~tx2+tx3+p2+p3+ptx2+ptx3+strata(id),data=xover3)

summary(xover3.cl)



#---------------------------------------------------#
#                   2*2  Crossover trial                 #
#---------------------------------------------------#

# Crossover trial

xover <- read.table("xover1.data",col.names=c("id","class","y",
 "intercept","trt","period","xover","BA"))
xover$trtA <- as.numeric(xover$trt!=1)
xover$xoverA <- xover$trtA*xover$period
with(xover,ftable(BA,trtA,y))

library(survival)
library(glmmML)
library(geepack)

xover.cl<-clogit(y~trtA+strata(id),data=xover)
xover.gee <-geese(y~trtA,data=xover,corstr="exchangeable",id=id,family=binomial,scale.fix=TRUE)
xover.glmm <-glmmML(y~trtA,data=xover,cluster=id,family=binomial)

summary(xover.cl)
summary(xover.gee)
summary(xover.glmm)



#---------------------------------------------------#
#                    Teratology Data                   #
#---------------------------------------------------#

setwd('D:/저서-번역/경시적자료분석/Codes')

tera <- read.table("tera.dat",col.names = c("litter", "group", "n", "y"))
tera$group <- factor (tera$group)
tera[1:5,]

# logistic regression model
tera.glm<- glm(cbind(y,n-y)~group,family=binomial,data=tera)
summary (tera.glm)

#png('tera.png')
plot(tera$n,resid(tera.glm,type="pearson"),xlab="Litter Size",ylab = "Pearson’s Residual (Binomial)",
     main = "Moore’s Teratology Data")
#dev.off()

# dispersion parameter phi 
pearson.residuals <- resid(tera.glm,"pearson")
phi <- sum(pearson.residuals^2)/tera.glm$df.residual
phi

## Quasi-likelihood Model 1
tera.quasi <- glm(cbind(y,n-y)~group,data=tera,family=quasibinomial)
summary (tera.quasi)

## GEE and Empirical Standard Errors
library(gee)
tera.gee <- gee(cbind(y,n-y)~group,data=tera,id = litter,family=binomial)
summary (tera.gee)


## Beta-Binomial Model: Maximum likelihood
library (rmutil) # You can download the library at http://www.commanster.eu/rcode.html
library (gnlm)  # for 'gnlr' function
tera$g2 <- as.numeric(tera$group == 2)
tera$g3 <- as.numeric(tera$group == 3)
tera$g4 <- as.numeric(tera$group == 4)
library (boot)  # for 'inv.logit' function
attach (tera)
tera.gnlr2 <- gnlr(cbind(y,n - y),distribution="beta binomial",mu=function(beta){
 inv.logit(beta[1]+beta[2]*g2+beta[3]*g3+beta[4]*g4)
 },pmu=c(1, -3, -4, -4),pshape = 2)
tera.gnlr2

tera.gnlr <- gnlr(cbind(y,n-y),distribution="beta binomial",mu=function(beta){
 inv.logit (beta[1]+beta[2]*g2+beta[3]*g3+beta[4]*g4)
 },pmu = c(1, -3, -4, -4),shape=finterp(~ n),pshape=c(2,0.5))
tera.gnlr








#---------------------------------------------------#
#           Bivariate normal distribution           #
#---------------------------------------------------#

library(mvtnorm)
y1 <- seq(from=-5,to=5,by=0.2)
y2 <- seq(from=-5,to=5,by=0.2)
mean <-c(0,0)
sigma <-matrix(c(1,0.5,0.5,1),ncol=2)

gaussian_func <- function(x, y) {
  dmvnorm(cbind(x, y),mean=mean,sigma=sigma)
}
z <- outer(y1,y2, gaussian_func)
png("bivariate.png")
persp(x=y1,y=y2,z=z, phi=30, theta=20,xlab="y1",ylab="y2",zlab="density")
dev.off()



