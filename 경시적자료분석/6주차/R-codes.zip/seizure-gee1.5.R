# Seizure Data: GEE1.5

setwd('d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')
library(gee)
library(geepack)

seize<-read.table("seize.data",col.names=c("id","seizure","week","progabide","baseline8","age"))
seize.base <- data.frame(id=seize$id,seizure=seize$baseline8,week=seize$week,progabide=seize$prog,age=seize$age)
seize.base <- seize.base[seize.base$week==1,]
seize.base$week<-0
seize.full<-rbind(seize[,c(1:4,6)],seize.base[,])
seize.full <- seize.full[order(seize.full$id,seize.full$week),]
seize.full$time <- ifelse(seize.full$week==0,8,2)
seize.full$post <- seize.full$week!= 0

z <- cbind(1,seize.full$age[seize.full$week==0])
sg2 <-geese(seizure~progabide+post+post:progabide+offset(log(time)),
            sformula=~progabide,data=seize.full,id=id,family="poisson",
            cor.link="fisherz",zcor=z,corstr="exchangeable")
summary(sg2)

sg2 <-geese(seizure~progabide+post+post:progabide+offset(log(time)),
            data=seize.full,id=id,family="poisson",
            corstr="exchangeable",jack=TRUE,j1s=TRUE,fij=TRUE)
summary(sg2)
