#-------------------------------------------------------#
#                 Crossover trial                       #
#-------------------------------------------------------#

setwd('d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')

xover3 <- read.table("xover3.data",col.names=c("id","class","relief",
 "intercept","tx2","tx3","p2","p3","ptx1","ptx2","ptx3"))
xover3$period <- ifelse(xover3$p2==1,2, ifelse (xover3$p3==1,3,1))
xover3$treatment <- ifelse(xover3$tx2==1,2, ifelse(xover3$tx3==1,3,1))  
with(xover3,ftable(period,relief,treatment))

xover3$ptx <- ifelse(xover3$ptx1==1,1,
                   ifelse(xover3$ptx2==1,2,3))
xover3$ptx[xover3$period==1]<-0
with(xover3,ftable(ptx,relief,treatment))

library(gee)

xover.gee <- gee(relief~p2+p3+tx2+tx3+ptx2+ptx3,
                 data=xover3,scale.fix=TRUE,id = id,family = binomial)
summary(xover.gee)


# Code for Conditional Logisitic Regression
library(survival)
xover3.cl <- clogit(relief~tx2+tx3+p2+p3+ptx2+ptx3+strata(id),data=xover3)

summary(xover3.cl)


#-----------------------------------------------------------#
#                     ICHS Data                             #
#-----------------------------------------------------------#

setwd('d:/course/SKKU/Longitudinal_Data_Analysis/R-codes')

ICHS <- read.table("ICHS.dat", header = TRUE)
ICHS
library (gee)
ig1 <- gee(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
           scale.fix=TRUE,cor="exchangeable",
           id=ID,data=ICHS,family="binomial")
summary(ig1)

summary(glm(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
           data=ICHS,family="binomial"))


library (geepack)
ig2 <- geese(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
             id=ID,corstr="exchangeable",data=ICHS,family="binomial")
summary (ig2)


#-----------------------------------------------------------#
#                   Seizure Data                            #
#-----------------------------------------------------------#

setwd('d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')
library(gee)
library(geepack)

seize<-read.table("seize.data",col.names=c("id","seizure","week","progabide","baseline8","age"))
seize.base <- data.frame(id=seize$id,seizure=seize$baseline8,week=seize$week,progabide=seize$prog,age=seize$age)
seize.base <- seize.base[seize.base$week==1,]
seize.base$week<-0
seize.full<-rbind(seize[,c(1:4,6)],seize.base[,])
seize.full <- seize.full[order(seize.full$id,seize.full$week),]
seize.full$time <- ifelse(seize.full$week==0,8,2)
seize.full$post <- seize.full$week!= 0
seize.full[1:10,]

sg2<-gee(seizure~progabide+post+post:progabide+offset(log(time)), 
         data=seize.full,id=id,family="poisson",cor="exchangeable")
summary(sg2)

sg2 <- geese(seizure ~ progabide+post+post:progabide+offset(log(time)),
             sformula= ~ progabide,data=seize.full,id=id,family="poisson",
             corstr="exchangeable")
summary(sg2)


#-----------------------------------------------------------#
#                  Seizure Data: GEE1.5                     #
#-----------------------------------------------------------#

z <- cbind(1,seize.full$age[seize.full$week==0])
sg2 <-geese(seizure~progabide+post+post:progabide+offset(log(time)),
            sformula=~progabide,data=seize.full,id=id,family="poisson",
            cor.link="fisherz",zcor=z,corstr="exchangeable")
summary(sg2)

sg2 <-geese(seizure~progabide+post+post:progabide+offset(log(time)),
            data=seize.full,id=id,family="poisson",
            corstr="exchangeable",jack=TRUE,j1s=TRUE,fij=TRUE)
summary(sg2)




#-----------------------------------------------------------#
#                   ALR Example                             #
#-----------------------------------------------------------#


setwd('d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')

# Crossover trial

xover3 <- read.table("xover3.data",col.names=c("id","class","relief",
 "intercept","tx2","tx3","p2","p3","ptx1","ptx2","ptx3"))

x<-as.matrix(xover3[,c("p2","p3","tx2","tx3","ptx2","ptx3")])
y <- xover3$relief

library(alr)
xover.alr <- alr(y~x,id=xover3$id,ainit=0.01,depmodel="exchangeable")
summary(xover.alr)

z <- matrix(c(1,0,0,
              0,1,0,
              0,0,1,
              1,0,0,
              0,1,0,
              0,0,1),ncol=3,byrow=TRUE)
xover.alr <- alr(y~x,id=xover3$id,z=z,zmast=1,
                 zlocs=rep(1:3,86),ainit=rep(0.01,3),
                 depmodel="general")
summary(xover.alr)


