setwd('d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')

# Crossover trial

xover3 <- read.table("xover3.data",col.names=c("id","class","relief",
 "intercept","tx2","tx3","p2","p3","ptx1","ptx2","ptx3"))

x<-as.matrix(xover3[,c("p2","p3","tx2","tx3","ptx2","ptx3")])
y <- xover3$relief

library(alr)
xover.alr <- alr(y~x,id=xover3$id,ainit=0.01,depmodel="exchangeable")
summary(xover.alr)

z <- matrix(c(1,0,0,
              0,1,0,
              0,0,1,
              1,0,0,
              0,1,0,
              0,0,1),ncol=3,byrow=TRUE)
xover.alr <- alr(y~x,id=xover3$id,z=z,zmast=1,
                 zlocs=rep(1:3,86),ainit=rep(0.01,3),
                 depmodel="general")
summary(xover.alr)


