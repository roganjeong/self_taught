# Seizure Data

setwd('e:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')
library(gee)
library(geepack)
library(repeated)

data(seize)
seizure

seiz.l <- reshape(seizure,varying=list(c("base","y1","y2","y3","y4")),
                  v.names="y", times=0:4, direction="long")
seiz.l <- seiz.l[order(seiz.l$id, seiz.l$time),]
seiz.l$t <- ifelse (seiz.l$time == 0, 8, 2)
seiz.l$x <- ifelse (seiz.l$time == 0, 0, 1)

# GEE
geese(y~offset(log(t))+x+trt+x:trt,id=id,
      data=seiz.l, subset=id!= 49,
      corstr = "exch", family=poisson)

# Poisson-Gaussian model: random intercept
glmmPQL(y ~ x + trt + x:trt + offset (log (t)),
        random = ~ 1 | id, family = poisson,
        data = seiz.l[seiz.l$id != 49,])

# Poisson-Gaussian model: random intercept and random slope for post
glmmPQL(y ~ x + trt + x:trt + offset (log (t)),
        random = ~ x | id,family = poisson,
        data = seiz.l[seiz.l$id != 49,])

