# Seizure Data

setwd('d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')

seize<-read.table("seize.data",col.names=c("id","seizure","week","progabide","baseline8","age"))

seize.lm <- glm(I(log(seizure+0.5))~age+baseline8+progabide,
                data=seize,subset=week==4,family=gaussian)
summary(seize.lm)

seize.glm <- glm(seizure~age+baseline8+progabide,
                 data=seize,subset=week==4,family=poisson)
summary(seize.glm)

seize.glm2 <- glm(seizure~age+baseline8+progabide,
                 data=seize,subset=week==4,
                 family=quasi(link=log,variance="mu"))
summary(seize.glm2)

