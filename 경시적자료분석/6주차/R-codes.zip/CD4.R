setwd("d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes")

# Scatter plot
png("ch1-pic1.png")
#pdf("ch1-pic1.pdf")
CD4 <- read.table("cd4.dat",header=TRUE)
plot(CD4 ~ Time, data=CD4, pch=".",
     xlab="Years since seroconversion",
     ylab="CD4+ cell number")
dev.off()


# Spaghetti plot
library(lattice)
png("ch1-pic2.png")
#pdf("ch1-pic2.pdf")
xyplot(CD4 ~ Time, data=CD4, type="l", group=ID,
       xlab="Years since seroconversion",
       col.line="gray20",
       ylab="CD4+ cell numbers")
dev.off()


# Choose 4 random individuals
png("ch1-pic3.png")
#pdf("ch1-pic3.pdf")
s <- sample(unique(CD4$ID),size=4)
plot(CD4 ~ Time, data=CD4, col="gray50",
     xlab="Years since seroconversion",
     ylab="CD4+ cell number")
for(i in 1:4){
 lines(CD4$Time[CD4$ID==s[i]],
       CD4$CD4[CD4$ID==s[i]],lwd=1.5)
}
dev.off()


# ZAP plot
#pdf("ch1-pic4.pdf")
cd4.lo <- loess(CD4 ~ Time, span=0.25,
                degree=1, data=CD4)
CD4$res <- resid(cd4.lo)

aux <- sort(tapply(CD4$res,CD4$ID,median))
aux <- aux[c(1,round((1:4)*length(aux)/4))]
aux <- as.numeric(names(aux))
leg <- c("0%", "25%", "50%", "75%", "100%")

plot(res ~ Time, data=CD4, col="gray70",
     xlab="Years since seroconversion",
     ylab="Residual Sqrt Root of CD4+ cell number")
with(CD4,
     for(i in 1:5){
       subset <- ID==aux[i]
       lines(Time[subset],res[subset], lwd=2,lty=i)
       text(Time[subset][1], res[subset][1], labels=leg[i])
     })
#dev.off()




# Relationship with covariates
#pdf("ch1-pic5.pdf")
xyplot(CD4 ~ Time | equal.count(Age,6), data=CD4,
       type="l", group=ID,
       xlab="Years since seroconversion",
       col.line="gray20",
       ylab="CD4+ cell number",
       strip=strip.custom(var.name="Age"))
#dev.off()


# Smoothing Spline
#pdf("ch1-pic6.pdf")
plot(CD4 ~ Time, data=CD4, col="gray50", pch=".",
     xlab="Years since seroconversion",
     ylab="CD+ cell number")
with(CD4, {
   lines(ksmooth(Time, CD4, kernel="box"),lty=1,col=1,lwd=2)
   lines(ksmooth(Time, CD4, kernel="normal"),lty=1,col=2,lwd=2)
   lines(loess.smooth(Time,CD4,family="gaussian"),lty=3,col=3,lwd=2)
   lines(smooth.spline(Time,CD4),lty=4,col=4,lwd=2)
   lines(supsmu(Time,CD4),lty=5,col=5,lwd=2)
})
legend(2,3000,legend=c("Boxcar", "Gaussian Kernal", "Gaussian Loess",
        "Gubic Smooth Spline", "Super Smoother"),
        lty=1:5,col=1:5)
#dev.off()


# Exploring Correlation structure
#pdf("ch1-pic7.pdf")
CD4.lm <- lm(CD4 ~ Time, data=CD4)
CD4$lmres <- resid(CD4.lm)
CD4$roundyr <- round(CD4$Time)
## put histograms on the diagonal
panel.hist <- function(x,...){
 usr <- par("usr"); on.exit(par(usr))
 par(usr=c(usr[1:2],0,1.5))
 h <- hist(x,plot=FALSE)
 breaks <- h$breaks; nB <- length(breaks)
 y <-h$counts; y<-y/max(y)
 rect(breaks[-nB],0,breaks[-1],y,col="cyan",...)
}
## put (absolute) correlations on the upper panels
## with size proportional to the correlations.
panel.cor <- function(x,y,digits=2, prefix="",cex.cor){
  usr <- par("usr"); on.exit(par(usr))
  par(usr=c(0,1,0,1))
  r <- abs(cor(x,y,use="pairwise.complete.obs"))
  txt <- format(c(r,0.123456789),digits=digits)[1]
  txt <- paste(prefix,txt,sep="")
  if(missing(cex.cor)) cex <- 0.8/strwidth(txt)
  text(0.5,0.5,txt,cex=cex*r)
}
CD4w <- reshape(CD4[,c("ID","lmres","roundyr")],
                 direction="wide",v.names="lmres",
                 timevar="roundyr",idvar="ID")
                 
pairs(CD4w[,c(5,2,3,6:8)],upper.panel=panel.cor,diag.panel=panel.hist)
#dev.off()


# Variogram
pdf("ch1-pic8.pdf")
lda.vg <- function(id,res,time,plot=TRUE,...)
{
  vv <- tapply(res,id,function(x) outer(x,x,function(x,y)(x-y)^2/2))
  v <- unlist(lapply(vv,function(x) x[lower.tri(x)]))
  uu <- tapply(time,id,function(x) outer(x,x,function(x,y)(x-y)))
  u <- unlist (lapply(uu , function (x) x[ lower.tri(x)]))
  if ( plot ) {
    vg.loess <- loess.smooth (u,v,family=" gaussian ")
    plot(v~u,pch=".",col="gray50", ...)
    lines (vg.loess,lty=1)
    abline(h=var(res),lty=2)
  }
  invisible ( data.frame (v = v, u = u))
}
lda.vg (CD4$ID,CD4$lmres,CD4$Time,ylim=c(0,170000),ylab="",xlab="")
dev.off()

