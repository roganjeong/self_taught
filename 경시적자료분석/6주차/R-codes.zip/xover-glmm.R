setwd('d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')

# Conditional logistic regression
library(survival)
xover3 <- read.table("xover3.data",col.names=c("id","class","relief",
           "intercept","tx2","tx3","p2","p3","ptx1","ptx2","ptx3"))

xover3.cl <- clogit(relief~tx2+tx3+p2+p3+ptx2+ptx3+strata(id),data=xover3)
summary(xover3.cl)


# Crossover trial

xover <- read.table("xover1.data",col.names=c("id","class","y",
 "intercept","trt","period","xover","BA"))
xover$trtA <- as.numeric(xover$trt!=1)
xover$xoverA <- xover$trtA*xover$period
with(xover,ftable(BA,trtA,y))

library(survival)
library(glmmML)
library(geepack)

xover.cl<-clogit(y~trtA+strata(id),data=xover)
xover.gee <-geese(y~trtA,data=xover,corstr="exchangeable",id=id,family=binomial,scale.fix=TRUE)

xover.glmm <-glmmML(y~trtA,data=xover,cluster=id,family=binomial)



# Crossover trial3

library(MASS)
xover3 <- read.table("xover3.data",col.names=c("id","class","relief",
 "intercept","tx2","tx3","p2","p3","ptx1","ptx2","ptx3"))

xover3.glmm <-glmmPQL(fixed=relief~tx2+tx3+p2+p3+ptx2+ptx3, 
                     random = ~ 1 | id,family = "binomial",data = xover3)
summary(xover3.glmm)

xover3.glmmML<- glmmML(relief~tx2+tx3+p2+p3+ptx2+ptx3,
                       cluster=xover3$id,family=binomial,
                       data=xover3,n.points = 20)
summary(xover3.glmmML)




