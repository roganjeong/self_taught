setwd('d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')

# Crossover trial

xover3 <- read.table("xover3.data",col.names=c("id","class","relief",
 "intercept","tx2","tx3","p2","p3","ptx1","ptx2","ptx3"))
xover3$period <- ifelse(xover3$p2==1,2, ifelse (xover3$p3==1,3,1))
xover3$treatment <- ifelse(xover3$tx2==1,2, ifelse(xover3$tx3==1,3,1))  
with(xover3,ftable(period,relief,treatment))

xover3$ptx <- ifelse(xover3$ptx1==1,1,
                   ifelse(xover3$ptx2==1,2,3))
xover3$ptx[xover3$period==1]<-0
with(xover3,ftable(ptx,relief,treatment))

library(gee)

xover.gee <- gee(relief~p2+p3+tx2+tx3+ptx2+ptx3,
                 data=xover3,scale.fix=TRUE,id = id,family = binomial)
summary(xover.gee)


# Code for Conditional Logisitic Regression
library(survival)
xover3.cl <- clogit(relief~tx2+tx3+p2+p3+ptx2+ptx3+strata(id),data=xover3)

summary(xover3.cl)
