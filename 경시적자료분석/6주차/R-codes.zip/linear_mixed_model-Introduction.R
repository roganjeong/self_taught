library(nlme)
data(Orthodont)

# Two Stage Analysis
OrthFem <- subset(Orthodont,Sex=="Female")
OrthFem[1:5,]

of.lis <-lmList(distance~I(age-11),data=OrthFem)
coef(of.lis)
plot(intervals(of.lis))


# Fixed Effects
of.lm <- lm(distance~factor(Subject,ordered=FALSE)+I(age-11)-1,data=OrthFem)

library(MASS)
confint(of.lm)
apply(intervals(of.lis)[,,2],2,mean)

# Linear Mixed Model
of.lme <- lme(distance~I(age-11)-1,random=~1|Subject,data=OrthFem)
intervals(of.lme)
orth.i <-cbind(two.stage=coef(of.lis)[,1],
               fixed=coef(of.lm)[1:11],
               random=coef(of.lme)[,1])
rownames(orth.i) <-NULL
orth.i
