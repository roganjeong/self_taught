setwd('D:/����-����/������ڷ�м�/Codes')

tera <- read.table("tera.dat",col.names = c("litter", "group", "n", "y"))
tera$group <- factor (tera$group)
tera[1:5,]

tera.glm<- glm(cbind(y,n-y)~group,family=binomial,data=tera)
summary (tera.glm)

plot(tera$n,resid(tera.glm,type="pearson"),xlab="Litter Size",ylab = "Pearson��s Residual (Binomial)",
     main = "Moore��s Teratology Data")

pearson.residuals <- resid(tera.glm,"pearson")
phi <- sum(pearson.residuals^2)/tera.glm$df.residual
rho <- 0.188

## Calculate sandwich variance estimates
X <- model.matrix (tera.glm)
mu <- fitted (tera.glm)
V.mu <- tera$n * mu * (1 - mu)

## Matrix A^-1
Ainv <- solve (t(X) %*% diag (V.mu) %*% X)
## Model Based Standard Error Estiamtes
se.model <- sqrt (diag (Ainv))
## Sandwich Estimates with Scale Variance
se.scaled <- sqrt (phi) * se.model
## Sandwich Estimates With Beta-Binomial Variance
B <- t(X) %*% diag (V.mu * (1 + rho * (tera$n - 1))) %*% X
se.sandwich <- sqrt (diag (Ainv %*% B %*% Ainv))
## Empirical Sandwich Estimates
est.fnx <- X * (tera$y - tera$n * mu)
UUt <- t(est.fnx) %*% est.fnx
se.empirical <- sqrt (diag (Ainv %*% UUt %*% Ainv))
round (cbind (coef (tera.glm),se.model,se.scaled,se.sandwich,se.empirical),4)

## Quasi-likelihood Model 1
tera.quasi <- glm(cbind(y,n-y)~group,data=tera,family=quasibinomial)
summary (tera.quasi)


## GEE and Empirical Standard Errors
library(gee)
tera.gee <- gee(cbind(y,n-y)~group,data=tera,id = litter,family=binomial)
summary (tera.gee)

## Quasi-likelihood Model 2
#source ("bod_regn.R")
#x <- cbind(1,tera$g2,tera$g3,tera$g4)
#tera.bod <- bod.regn(y=tera$y,n=tera$n,x=x,dispersion="correlation",beta=c(1,-3,-4,-4),alpha=2)
#summary(tera.bod)

## Beta-Binomial Model: Maximum likelihood
library (rmutil) # You can download the library at http://www.commanster.eu/rcode.html
library (gnlm)  # for 'gnlr' function
tera$g2 <- as.numeric(tera$group == 2)
tera$g3 <- as.numeric(tera$group == 3)
tera$g4 <- as.numeric(tera$group == 4)
library (boot)  # for 'inv.logit' function
attach (tera)
tera.gnlr2 <- gnlr(cbind(y,n - y),distribution="beta binomial",mu=function(beta){
 inv.logit(beta[1]+beta[2]*g2+beta[3]*g3+beta[4]*g4)
 },pmu=c(1, -3, -4, -4),pshape = 2)
tera.gnlr2

tera.gnlr <- gnlr(cbind(y,n-y),distribution="beta binomial",mu=function(beta){
 inv.logit (beta[1]+beta[2]*g2+beta[3]*g3+beta[4]*g4)
 },pmu = c(1, -3, -4, -4),shape=finterp(~ n),pshape=c(2,0.5))
tera.gnlr


