setwd("d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes")

madras <- read.table('madras.dat',col.names=c("id","thoughts","month",
                     "age","gender","month.age","month.gender"))
madras.w <-reshape(madras[,1:5],direction="wide",
                   v.names="thoughts",timevar="month",idvar="id")
thoughts <-madras.w[,-c(1:3)]
n <-ncol(thoughts)
ttall <-array(0,dim=c(nrow(thoughts),2,2,n-1))
tt <- matrix(0,2,2)
for(i in 1:nrow(thoughts)){
  y <-as.numeric(thoughts[i,])
  for(lag in 1:(n-1)){
    tmp <-cbind(y[1:(n-lag)],y[(lag+1):n])
    tmp <-na.omit(tmp)
    tt[1,1] <-sum(tmp[,1]+tmp[,2]==0)
    tt[2,2] <-sum(tmp[,1]+tmp[,2]==2)
    tt[1,2] <-sum(tmp[,2]+tmp[,1]==1)
    tt[2,1] <-sum(tmp[,2]+tmp[,1]==-1)
    ttall[i,,,lag] <-tt
  }
}
ttacross <- apply(ttall,c(2,3,4),sum)

library(vcd)
plot(oddsratio(ttacross),ylim=c(-1,4.5),xlab="Time Lag (month)",
     main="MADRAS Study: Thoughts")

