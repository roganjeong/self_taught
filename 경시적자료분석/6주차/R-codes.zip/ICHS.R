# ICHS Data

setwd("e:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes")

ICHS <- read.table("ICHS.dat", header = TRUE)
ICHS

library (gee)
ig1 <- gee(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
           scale.fix=TRUE,cor="exchangeable",
           id=ID,data=ICHS,family="binomial")
summary(ig1)

ig.glm <-glm(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
           data=ICHS,family="binomial")
summary(ig.glm)


library (geepack)
ig2 <- geese(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
             id=ID,corstr="exchangeable",data=ICHS,family="binomial")
summary (ig2)





