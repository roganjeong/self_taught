# Indonesian Children Health Study


setwd('e:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes')


ICHS <- read.table("ICHS.dat", header = TRUE)
ichs.glmm <- glmmPQL(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME,
                     random= ~ TIME | ID,
                     data=ICHS,family="binomial")
summary(ichs.glmm)

truehist(ranef(ichs.glmm)[,1], xlab = "Intercept")
truehist(ranef(ichs.glmm)[,2], xlab = "Time")


ichs.glmmPQL<-glmmPQL(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME,
                      random = ~ 1 | ID,data=ICHS,family="binomial")
summary(ichs.glmmPQL)


library(repeated)
ichs.glmm2 <- glmm(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME,nest=ID,
                   data=ICHS,family="binomial",points = 20)
summary (ichs.glmm2)

ichs.glmm3 <- glmm(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),nest=ID,
                   data=ICHS,family="binomial",points = 20)
summary (ichs.glmm3)


library(glmmML)
ichs.glmmML <-glmmML(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME,
                     cluster=ICHS$ID,data=ICHS,family=binomial,n.points=20)
summary(ichs.glmmML)

ichs.glmmML1 <-glmmML(RESPONSE~VITA+AGE+I(AGE^2)+GENDER+TIME+I(TIME^2),
                     cluster=ICHS$ID,data=ICHS,family=binomial,n.points=20)
summary(ichs.glmmML1)
