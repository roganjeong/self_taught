setwd("d:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes")

# ICHS: Checking Endogeneity

xerop <- read.table('xerop.dat',col.names=c("id","RI","intercept","age",
          "xero","cos.time","sin.time","sex","height.age","stunted","time",
          "base.age","season","time.time"))
xeropw <- reshape(xerop,direction="wide",v.names=c("RI","xero","age","height.age"),
           idvar=c("id","sex"),timevar="time",
           drop=c("intercept","cos.time","sin.time","stunted",
                  "base.age","season","time.time"))
summary(glm(xero.2~xero.1+RI.1,family="binomial",data=xeropw))
summary(glm(xero.3~xero.2+xero.1+RI.1+RI.2,family="binomial",data=xeropw))
summary(glm(xero.3~xero.2+RI.2+RI.1,family="binomial",data=xeropw))


# MSCM Study: Marginal Association
library(gee)
mscm.temp <- read.table('mscm.dat',col.names=c("id","day","stress","s1","s2","s3",
                   "s4","s5","s6","illness","i1","i2","i3","i4","i5","i6",
                   "married","education","employed","chlth","mhlth","race",
                   "csex","housize","billness","bStress"))
week<-rep(0,length(mscm.temp[,1]))
for(i in 1:length(mscm.temp[,1])){
 if(mscm.temp$day[i]<=7){
   week[i]<-1
 }else if(mscm.temp$day[i]<=14){
   week[i]<-2
 }else if(mscm.temp$day[i]<=21){
   week[i]<-3
 }else if(mscm.temp$day[i]<=28){
   week[i]<-4
 }else{
   week[i]<-5
 } 
}

mscm <- cbind(mscm.temp,week)

m.ind <-gee(illness~stress+week+married+employed+chlth+mhlth+race+education+housize,
             data=mscm,id=id,family=binomial)
m.ex <-gee(illness~stress+week+married+employed+chlth+mhlth+race+education+housize,
             data=mscm,id=id,corstr="exchangeable",family=binomial)
m.ar1 <-gee(illness~stress+week+married+employed+chlth+mhlth+race+education+housize,
             data=mscm,id=id,corstr="AR-M",Mv=1,family=binomial)
res <-lapply(list(independent=m.ind,exchangeable=m.ex,ar1=m.ar1),
              function(x)(coef(summary(x))[2:3,c(1,4,5)]))

options(digits=3)
res
m.ex$working.correlation[1,2]
m.ar1$working.correlation[1,2]


#library(wavethresh)
#library(adlift)
#library(binhf)
#mscm$s7 <-shift(mscm$s6,id=mscm$id)
il.lags <-list()
for(ii in paste("s",1:7,sep="")){
  il.lags[[ii]] <-gee(illness~mscm[,ii]+week+married+employed+chlth+mhlth+race+
                         education+housize,data=mscm,id=id,family=binomial)
}

il.lags.coef <-do.call("rbind",lapply(il.lags,function(x){
                          coef(summary(x))[2,c(1,4)]}))
il.lags.coef <-data.frame(il.lags.coef)
names(il.lags.coef) <-c("beta","se")

library(Hmisc)
with(il.lags.coef,{
  plot(beta,xlim=c(0,30),ylim=c(-0.6,0.8),
        xlab="Time lag (days)",
        ylab="Coefficient (log odds ratio)",
        main="MSCM Study: Lag coefficient function")
  abline(h=0,lty=2)
  errbar(1:6,beta,beta-1.96*se,beta+1.96*se,add=TRUE)
})

