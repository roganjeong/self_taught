setwd("d:/course/SKKU/Longitudinal_Data_Analysis/2015Fall/R-codes")

library(nlme)

#------------------------------------------#
## Grouped data

tracking <- read.table ("tracking.dat", header = TRUE)
tracking

tracklong <- reshape (tracking, direction = "long",
 varying = 4:7, times = 1:4,
 split = list (regexp = "l", include = TRUE))

tracklong[1:10,]

tracklong <- tracklong[order (tracklong$id, tracklong$time),]
tracklong <- groupedData (Trial ~ time | id, data = tracklong,
 outer = ~ Sex * Shape)

gsummary (tracklong)
gsummary (tracklong, inv = TRUE, omit = TRUE)
gapply (tracklong, "Trial", sd)

plot (tracklong, outer = TRUE, aspect = "fill",
 xlab = "Trial", ylab = "Contact Time (sec)",
 auto.key = FALSE, key = NULL)

track.sum <- gsummary(tracklong)
pdf("trackinghist.pdf", height = 8, width = 8)
hist(Trial | Sex*Shape, data = track.sum)
dev.off()


#-----------------------------------------#
## Orthodontic Data

data(Orthodont)
o10.lm <- lm(distance ~ age * Sex, data = Orthodont)
summary(o10.lm)

anova(o10.lm)

drop1(o10.lm, scope = c("Sex", "age:Sex"), test = "F")
o20.lm <- update(o10.lm, ~ . - age:Sex)
summary(o20.lm)

library(lattice)
#pdf("ortho_lm.pdf", height = 8, width = 8)
bwplot(getGroups (Orthodont) ~ residuals (o10.lm))
#dev.off ()

o10.lis <- lmList(distance ~ age, data = Orthodont)
pairs(o10.lis, id = 0.01, adj = -0.5)
plot(intervals (o10.lis))

# "Fitting general linear model
o10.lm1 <- gls(distance ~ I(age - 11) * factor(Sex), data = Orthodont,method="ML",
              correlation=corCompSymm(form=~1|Subject))
summary(o10.lm1)


# Fitting linear mixed model with lme
o10.lme <- lme(distance ~ I(age - 11),
 data = Orthodont,
 random = ~ I(age - 11) | Subject)
summary(o10.lme)

#o20.lme <- update(o10.lme, distance ~ I(age - 11) * Sex)
o20.lme <- lme(distance ~ I(age - 11)*Sex,
 data = Orthodont,
 random = ~ I(age - 11) | Subject)

summary(o20.lme)

# Residuals
fitted(o20.lme, level = 0:1)
resid(o20.lme, level = 1, type = "p")

newO <- data.frame(Subject = rep (c ("M11", "F03"), each = 3),
 Sex = rep(c ("Male", "Female"), each = 3),
 age = rep(16:18, 2))
predict(o20.lme, newdata = newO)

# Prediction
predict(o20.lme, newdata = newO, level = 0:1)


o10.lis <- lmList(distance ~ I(age-11), data = Orthodont) # Linear Model
comp0 <- compareFits(coef(o10.lis), coef(o10.lme))
plot(comp0,mark=fixef(o10.lme))


plot(comparePred (o10.lis, o10.lme), length.out = 2,
 lty = 1:2, lwd = 1.5,
 col = "black", layout = c(8, 4), between = list (y = c(0, 0.5)))

o20.lme <- update(o10.lme, distance ~ I(age - 11) * Sex)
o20.lmeM <- update(o20.lme, method = "ML")
plot(compareFits (ranef (o20.lme), ranef (o20.lmeM)),
mark = c(0, 0))

o10.lm2 <- lm(distance ~ I(age - 11) * Sex, data = Orthodont)
anova(o20.lme, o10.lm2)

# For groupedData
o30.lme <- update(o10.lme, random = pdDiag (~ I(age - 11)))
# otherwise
o30.lme <- update(o10.lme,
   random = list (Subject = pdDiag (~ I(age - 11))))
summary(o30.lme)
anova(o10.lme, o30.lme)


o40.lme <- update(o10.lme, random = ~ 1 | Sex / Subject)
summary(o40.lme)
anova(o40.lme, o10.lme)
ranef(o40.lme, levels = 1:2)



# Model Diagnosis
plot(o20.lme, Subject ~ resid (.), abline = 0)
plot(o20.lme, resid (., type = "p") ~ fitted(.) | Sex,id = 0.05)

o25.lme <- update(o20.lme, weights = varIdent (form = ~ 1 | Sex))
summary(o25.lme)

anova(o25.lme, o20.lme)
qqnorm(o25.lme, ~ resid (.) | Sex)

# Checking the random effects
qqnorm(o20.lme, ~ ranef (.), id = 0.10)
qqnorm(o25.lme, ~ ranef (.), id = 0.10)

pairs(o20.lme, ~ ranef (.) | Sex, id = ~ Subject == "M13")
pairs(o25.lme, ~ ranef (.) | Sex, id = ~ Subject == "M13")


#--------------------------------------------#
## Multicenter AIDS Cohort Study: CD4+Data
library(nlme)
CD4 <- read.table("cd4.dat",header=TRUE)
CD4g <- groupedData(CD4 ~ Time | ID, data = CD4, FUN = median,
 labels = list (x = "Time since seroconversion",
 outer = ~ Age,
 labels = list (y = "CD4+ Cell Number")),
 units = list (x = "(yr)", y = ""))
gsummary(CD4g, inv = TRUE, omit = TRUE)[1:10,,drop = FALSE]
gsummary(CD4g, FUN = function (x) max (x, na.rm = TRUE))[1:10,]
gsummary(CD4g, FUN = function (x) min (x, na.rm = TRUE))[1:10,]

CD4$Time2 <- ifelse(CD4$Time < 0, 0, CD4$Time)
cd4.lm <- lm(I(sqrt (CD4)) ~ Cesd + Drugs + Sex + Packs +
 Time2 + I(Time2^2), data = CD4)
summary(cd4.lm)

par(mfrow = c(2, 2))
plot (cd4.lm)

temp <- subset(CD4, Time < 4)
cd4.lmt <- lm(I(sqrt (CD4)) ~ Time2 + I(Time2^2), data = temp)
temp$fitted <- fitted(cd4.lmt)^2
temp <- temp[order (temp$Time),]
plot(CD4 ~ Time, data = temp, col = "gray50", pch = ".",
 xlab = "Years since seroconversion", ylab = "CD4+ cell number")
lines(temp$fitted ~ temp$Time)

CD4.lst <- lmList(I(sqrt (CD4)) ~ Time2 + I(Time2^2)|ID, data = CD4)
plot(intervals (CD4.lst), layout = c(1, 3))

o10.lme <- lme(distance ~ I(age - 11),
 data = Orthodont,
 random = ~ I(age - 11) | Subject)
o15.lme <- update(o10.lme, distance ~ I(age - 11) + Sex)
ACF(o15.lme)
plot(ACF (o15.lme), alpha = 0.05)

Variogram(o15.lme)
plot(Variogram (o15.lme))


CD4.lme <- lme(I(sqrt (CD4)) ~ Cesd + Drugs + Sex + Packs +
 Time2 + I(Time2^2), data = CD4g,
 random = ~ 1 | ID)
plot(ACF (CD4.lme), alpha = 0.01)


Variogram (CD4.lme)
r <- tapply(resid (CD4.lme), CD4$ID, function (x) x)
dt <- tapply(CD4$Time, CD4$ID, function (x) {
 tmp <- outer (x, x, "-")
 abs (tmp[lower.tri(tmp)])
})
non.singles <- which (sapply (r, length) != 1)
r <- r[non.singles]
dt <- dt[non.singles]
CD4.v <- mapply (function (x, y) Variogram (x, y), r, dt,SIMPLIFY = FALSE)
CD4.v <- do.call ("rbind", CD4.v)
temp <- loess.smooth (x = CD4.v$dist, y = CD4.v$variog,
 family = "gaussian")
plot (variog ~ dist, data = CD4.v, ylim = c(0, 100), col = "gray70")
lines (temp, lty = 1, lwd = 2)
abline (h = var (unlist (r)), lwd = 2, lty = 2)

CD4.lme2 <- lme (I(sqrt (CD4)) ~ Cesd + Drugs + Sex + Packs +
 Time2 + I(Time2^2), data = CD4g,
 random = ~ 1 | ID,
 correlation = corExp (form = ~ Time, value = 0.1))
summary (CD4.lme2)

anova (CD4.lme2, CD4.lme)
intervals (CD4.lme2)
summary (CD4.lme)

