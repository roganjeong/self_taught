setwd("e:/course/SKKU/Longitudinal_Data_Analysis/2016Fall/R-codes")
library(lattice)

## Read data and compute some summary statistics
tlc <- read.table ("tlc.txt",col.names = c("ID", "Group", "week.0", "week.1", "week.4", "week.6"))
tlc[1:4,]
do.call ("rbind", tapply(tlc$week.0, tlc$Group, summary))
by( tlc[,-(1:2)],tlc$Group,function(x) cbind(mean=mean(x),sd=sd(x)))


## Explore data
tlcL <- reshape (tlc, direction = "long", idvar = "ID", varying = 3:6)
tlcL[95:105,]
names(tlcL)[3:4] <- c("Week", "Lead")


# Scatterplot by treatment group with LOESS smoothing curve
png('tlc-spaghetti.png')
xyplot (Lead ~ Week | Group, data = tlcL,
groups = tlcL$ID, type = "l",
panel = function(x, y, subscripts, groups, ...) {
panel.superpose (x, y,
panel.groups = "panel.xyplot",
subscripts,
groups, col = "gray40", ...)
panel.loess(x, y, col = "red", lwd = 2, ...)
})
dev.off()

## Correlation structure
panel.hist <- function (x, ...)
{
 usr <- par ("usr")
 on.exit (par (usr))
 par (usr = c (usr[1:2], 0, 1.5))
 h <- hist (x, plot = FALSE, probability = TRUE)
 breaks <- h$breaks
 nB <- length (breaks)
 y <- h$counts
 y <- y / max (y)
 rect (breaks[-nB], 0, breaks[-1], y,
 col = "cyan", ...)
 xd <- density (x)
 xd$y <- xd$y / max (xd$y)
 lines (xd, col = "brown", lwd = 1.5)
}

png('tlc-correlation.png')
panel.cor <- function(x, y, digits = 2, prefix = "", cex.cor)
{
 usr <- par ("usr")
 on.exit (par(usr))
 par (usr = c(0, 1, 0, 1))
 r <- abs (cor(x, y, use = "pairwise.complete.obs"))
 txt <- format (c(r, 0.123456789), digits=digits)[1]
 txt <- paste (prefix, txt, sep="")
 if (missing (cex.cor))
 cex <- 0.8 / strwidth (txt)
 text (0.5, 0.5, txt, cex = cex * r)
}
pairs (tlc[,3:6], diag.panel = panel.hist,
 upper.panel = panel.cor,
 lower.panel = panel.smooth)
dev.off()


## Simple Linear Model
temp <- lm(Lead ~ factor (Week) * Group, data = tlcL)
summary (temp)

anova (temp)

# Model diagnosis
par(mfrow=c(2,2))
plot(temp)

## GEE
library (gee)
tlcL <- tlcL[order(tlcL$Group,tlcL$ID,tlcL$Week),]

# default(independence working correlation)  
temp <- gee (Lead ~ factor (Week) * Group, id = ID, data = tlcL)
summary (temp)

# exchangeable working correlation
temp <- gee (Lead ~ factor (Week) * Group, id = ID,
 corstr = "exchangeable", data = tlcL)
summary (temp)

# unstructured working correlation
temp <- gee (Lead ~ factor (Week) * Group, id = ID,
 corstr = "unstructured", data = tlcL)
summary (temp)

## Generalized Least Squares
library(nlme)
# ML method
temp <- gls (Lead ~ factor (Week) * Group, data = tlcL, method = "ML",
 correlation = corCompSymm (form = ~ 1 | ID))
summary(temp)
anova (temp)
intervals (temp)

# REML method
temp <- gls (Lead ~ factor (Week) * Group, data = tlcL,
 correlation = corCompSymm (form = ~ 1 | ID))
summary(temp)
anova (temp)
intervals (temp)


## Bootstrap standard error estimates
#library (Design)
#temp <- glsD (Lead ~ factor (Week) * Group,
# data = tlcL,
# correlation = corCompSymm (form = ~ 1 | ID),
# B = 1000)
#temp
#anova (temp)

# Estimating the contrasts
#tlcL$wc <- factor (tlcL$Week)
#tempB <- glsD (Lead ~ wc * Group,
# data = tlcL,
# correlation = corCompSymm (form = ~ 1 | ID))

#wcl <- levels (tlcL$wc)
#contrast (tempB, list (Group = "A", wc = wcl), 
                 list (Group = "P", wc = wcl))

# Estimating mean responses
#newdata <- data.frame (expand.grid (wcl, c("A", "P")))
#names (newdata) <- c("wc", "Group")
#cbind (newdata, predict (tempB, newdata = newdata, conf.int = 0.95))

#tlc.means <- data.frame (newdata,
#predict (tempB, newdata = newdata,
#conf.int = 0.95))
#names (tlc.means)[3] <- "Lead"
#xYplot (Cbind (Lead, lower, upper) ~ as.numeric (as.character (wc)),
#group = Group,
#ylim = c(10, 30), xlab = "Weeks",
#ylab = "Mean Blood Lead Level",
#data = tlc.means)


# Dealing with baseline outcome
out1<-lm(week.1~Group, data=tlc)
summary(out1)

out1.0<-lm(I(week.1 - week.0) ~ Group, data = tlc)
summary(out1.0)

out1.grp.week0 <-lm(week.1 ~ Group + week.0, data = tlc)
summary(out1.grp.week0)

# Method 1
full.1 <- gls (Lead ~ factor (Week) * Group, method = "ML", data = tlcL,
  correlation = corCompSymm (form = ~ 1 | ID))
reduced.1 <- gls (Lead ~ factor (Week) + Group, method = "ML", data = tlcL,
  correlation = corCompSymm (form = ~ 1 | ID))
anova (full.1, reduced.1)

# Method 2
tlcL$W1P <- (tlcL$Week == 1) & (tlcL$Group == "P")
tlcL$W4P <- (tlcL$Week == 4) & (tlcL$Group == "P")
tlcL$W6P <- (tlcL$Week == 6) & (tlcL$Group == "P")
full.2 <- gls (Lead ~ factor (Week) + W1P + W4P + W6P, data = tlcL, method = "ML",
  correlation = corCompSymm (form = ~ 1 | ID))
reduced.2 <- gls (Lead ~ factor (Week), data = tlcL, method = "ML",
  correlation = corCompSymm (form = ~ 1 | ID))
anova (full.2, reduced.2)

# Method 3
tlcL2 <- reshape (tlc, direction = "long", idvar = "ID", varying = 4:6)
names (tlcL2)[3:5] <- c("BaseLead", "Week", "Lead")
tlcL2$ChangeLead <- tlcL2$Lead - tlcL2$BaseLead
tlcL2 <- tlcL2[order (tlcL2$Group, tlcL2$ID, tlcL2$Week),]

full.3 <- gls (ChangeLead ~ factor (Week) * Group, method = "ML", data = tlcL2,
 correlation = corCompSymm (form = ~ 1 | ID))
reduced.3 <- gls (ChangeLead ~ factor (Week), method = "ML", data = tlcL2,
 correlation = corCompSymm (form = ~ 1 | ID))
anova (full.3, reduced.3)

# Method 4
full.4 <- gls (Lead ~ factor (Week) * Group + BaseLead, method = "ML",data = tlcL2,
  correlation = corCompSymm (form = ~ 1 | ID))
reduced.4 <- gls (Lead ~ factor (Week) + BaseLead, method = "ML", data = tlcL2,
  correlation = corCompSymm (form = ~ 1 | ID))
anova (full.4, reduced.4)


## Model Diagnosis

# Residual Plots
plot (full.1, ID ~ resid (.), id = 0.01) 
plot (full.1, resid (.) ~ Week | Group, abline = 0,
 id = ~ ID == 40)
plot (full.1, resid (., type = "p") ~ fitted (.) | Group,id = ~ ID == 40)
plot (full.1, Lead ~ fitted (.))
qqnorm (full.1, ~ resid (.))



